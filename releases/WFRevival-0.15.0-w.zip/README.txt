WF Revival mod - version 0.15.0-w (Windows)
===========================================

For Warhammer 40,000: Warpforge 1.35.0 (Steam), with MelonLoader 0.7.3.

Install: copy the "WFRevival" folder from this zip into the game's "Mods" folder, so you end up with
    Mods\WFRevival\WFRevival.dll
    Mods\WFRevival\manifest.json
(keep manifest.json next to the DLL - without it the mod is not loaded).

Full step-by-step guide, with pictures:
    https://wf-revival.silentanarchist.com/guides/pc
The website needs an account: sign in or make one at https://wf-revival.silentanarchist.com/login
(an account still waiting for approval can already read the guides).

Already playing with an older version (WarpforgeRevival.dll)? Nothing to do: the game updates the mod
by itself and moves it to its new name.

Problems: send MelonLoader\Latest.log from the game folder, or press F8 in the game if you are a tester.
