Warpforge Revival mod - version 0.12.34-w (Windows)
==================================================

What you need first
-------------------
1. Warhammer 40,000: Warpforge installed (Steam).
2. MelonLoader 0.7.3 installed into the game folder.
   Run the MelonLoader installer, pick Warpforge, choose version 0.7.3.
   Start the game once afterwards and let it finish its first-time setup
   (a console window does some work, then the game opens). Close the game.

Installing the mod
------------------
1. Open the game folder. In Steam: right-click the game > Manage >
   Browse local files.
2. Open the "Mods" folder inside it (create it if it is not there).
3. Copy the whole "WarpforgeRevival" folder from this zip into "Mods".
   You should end up with:
       Mods\WarpforgeRevival\WarpforgeRevival.dll
       Mods\WarpforgeRevival\manifest.json
   Keep manifest.json next to the DLL - without it the mod is not loaded.
4. Start the game.

That is all. The mod already knows the server's address, and it keeps itself
up to date: when the server has a newer version, the sign-in window says so
while the game loads, downloads it, and the game closes and starts again with
it. Nothing to do on your side.

If the server asks for an account, a sign-in window appears while the game
loads. New player: type the name (5 to 30 characters) and password you want
into the boxes, then press Create account. Otherwise type your account's name
and password and press Sign in.
The game remembers the sign-in. To play as someone else on this computer, use
Sign out in Settings > Account - it signs out this computer only and your
account keeps its progress.

Forgotten your password? Make a recovery code on the website's Profile page
while you still know it, and keep the file it downloads. "Forgot your
password?" on the website's sign-in page takes the code and a new password.

If something goes wrong
-----------------------
- The game looks unmodded (no connection, original menus): check both files
  are in Mods\WarpforgeRevival\ and that MelonLoader is installed.
- Please send the file MelonLoader\Latest.log from the game folder when you
  report a problem. It says what happened.
- If you ran an older copy of this mod before and it cannot connect, delete
  UserData\WarpforgeRevival.cfg in the game folder and start the game again.

Good to know
------------
- The mod's version is shown next to the game's in Settings > General.
  Windows builds end in -w, Android builds in -a.
- The game no longer contacts Unity's online services (sign-in and usage
  reports that went to the publisher). Voice lines are unaffected.
- Keep the game window open while you wait for a match. Minimising is fine.
- Whether you need an account depends on the server. Where it is optional,
  you can link a site account in Settings > Account.
- The connection to the server is encrypted (https) when the server offers it,
  and so are matches against other players.

Your original game files are safe
---------------------------------
If you played Warpforge before its servers closed, your computer may still
hold the original game files in its cache. This mod never deletes them, and
it stops the game from deleting them. It also makes a second copy in the
game folder under UserData\WarpforgeRevival\original-cache.
If the server owner asks you for those files, zip that folder and send it.
