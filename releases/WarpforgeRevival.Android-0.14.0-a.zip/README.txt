Warpforge Revival mod for Android - version 0.14.0-a
====================================================

This is the mod only. The game on your device has to be patched with the mod loader
first. The easy way is the Warpforge Patcher app, which also puts this mod in place:
    https://github.com/silentanarchist/warpforge-revival-mod/blob/main/docs/android.md

Putting the mod on the device by hand
-------------------------------------
Either:
  a) copy WarpforgeRevival.Android.dll into the "mods" folder of the PC patcher
     and run "3 - put mod on phone.bat" (device connected by USB), or
  b) copy WarpforgeRevival.Android.dll on the device itself into
        MelonLoader/com.Everguild.WarhammerWarpforge/Mods/
     (internal storage) with a file manager.

Start the game. If the server asks for an account, a sign-in window appears.
New player: type the username (5 to 30 characters) and password you want into
the boxes, then press Create account. Otherwise type your account's username and
password and press Sign in. The device remembers the sign-in.

From then on the mod keeps itself up to date: when the server has a newer
version, the sign-in window says so while the game loads, downloads it, and
closes the game; open it again to use the new version.

In chat, the keyboard's check mark sends your message.

To play as someone else on this device, use Sign out in Settings > Account. It
signs out this device only; your account keeps its progress.

Forgotten your password? Make a recovery code on the website's Profile page
while you still know it, and keep the file it downloads. "Forgot your
password?" on the website's sign-in page takes the code and a new password.

Screen stays black after the opening video? (seen on a Pixel 6 Pro)
-------------------------------------------------------------------
The mod brings the picture back by itself within a second or two. To stop it
happening, run "6 - fix loading video.bat" (option 1) and then
"7 - loading video setting.bat" (option 1, Still) from the patcher: the
opening video is no longer played, and its last frame is shown as a picture
for the whole load instead. "6 - fix loading video.bat" also fixes a blocky
or stuttering opening video.

Screen goes black during a match? Switch on the game's own
Settings > Graphics > Extended compatibility, then restart the game.

The website shows official cards only from your own copy of the game:
Settings > Mod > Export card art saves them (art and card text) into
card-art-export.zip in the mod's UserData/WarpforgeRevival folder; load that
zip on the website's Profile page.

The mod's version is shown next to the game's in Settings > General.
Android builds end in -a, Windows builds in -w.

Matches against other players are encrypted when the server offers it, like
everything else the mod sends.

If something goes wrong
-----------------------
Run "0 - get phone logs.bat" from the patcher and send the folder it makes.
