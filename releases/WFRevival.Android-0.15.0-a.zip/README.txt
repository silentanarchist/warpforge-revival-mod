WF Revival mod - version 0.15.0-a (Android)
===========================================

For Warhammer 40,000: Warpforge 1.35.0 on Android, patched with the mod loader.

The easiest way: the WF Revival Patcher app patches the game and puts this mod in place for you.
Guides, with pictures:
    https://wf-revival.silentanarchist.com/guides/phone       (Patcher app, on the device)
    https://wf-revival.silentanarchist.com/guides/android-pc  (with a PC)
    https://wf-revival.silentanarchist.com/guides/mumu        (MuMu Player)
The website needs an account: sign in or make one at https://wf-revival.silentanarchist.com/login
(an account still waiting for approval can already read the guides).

By hand: the file goes to
    /sdcard/MelonLoader/com.Everguild.WarhammerWarpforge/Mods/WFRevival.Android.dll

Already playing with an older version (WarpforgeRevival.Android.dll)? Nothing to do: the game updates
the mod by itself and moves it to its new name. Warpforge Patcher 0.4.0 or older: install WF Revival
Patcher 0.4.1 by hand once (see the Patcher guide).
